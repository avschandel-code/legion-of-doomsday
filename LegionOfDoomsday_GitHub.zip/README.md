# Legion of Doomsday

Legion of Doomsday is a Python-based RPG adventure game with 25+ levels, avatar & pet selection, shops, quests, and achievements. Face monsters, upgrade gear, and uncover the shocking twist — your companion is the true Doomsday Master. Built with Tkinter & Pygame.

## How to Run
1. Install dependencies with `pip install pygame`.
2. Run `python 'Legion Of Doomsday.py'`.

## Packaging
Use PyInstaller:
```
pyinstaller --onefile --windowed --icon=icon.ico 'Legion Of Doomsday.py'
```